package com.benchmark.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenchmarkServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
