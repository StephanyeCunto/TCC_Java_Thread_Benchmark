package com.benchmark.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BenchmarkServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BenchmarkServerApplication.class, args);
	}

}
